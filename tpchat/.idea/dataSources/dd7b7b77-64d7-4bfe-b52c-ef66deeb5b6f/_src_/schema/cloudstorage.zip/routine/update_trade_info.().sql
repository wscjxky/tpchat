CREATE PROCEDURE update_trade_info()
  BEGIN
	DECLARE contractAmount DOUBLE;
	DECLARE extendStorageAmount DOUBLE;
	DECLARE rechargeAccountAmount DOUBLE;
	DECLARE memberShipTaxAmount DOUBLE;
	DECLARE totalAmount DOUBLE;

	SELECT SUM(`order`.Amount) INTO contractAmount FROM `order` JOIN contract_order on `order`.Id=contract_order.OrderId WHERE `order`.State = 1;
	SELECT SUM(`order`.Amount) INTO extendStorageAmount FROM `order` JOIN extendStorage_order on `order`.Id=extendStorage_order.OrderId WHERE `order`.State = 1;
	SELECT SUM(`order`.Amount) INTO rechargeAccountAmount FROM `order` JOIN rechargeAccount_order on `order`.Id=rechargeAccount_order.OrderId WHERE `order`.State = 1;
	SELECT SUM(`order`.Amount) INTO memberShipTaxAmount FROM `order` JOIN membershiptax_order on `order`.Id=membershiptax_order.OrderId WHERE `order`.State = 1;
	SELECT SUM(`order`.Amount) INTO totalAmount FROM `order` WHERE `order`.State = 1;

	IF ISNULL(contractAmount) THEN
		SET contractAmount = 0.0;
	END IF;
	IF ISNULL(extendStorageAmount) THEN
		SET extendStorageAmount = 0.0;
	END IF;
	IF ISNULL(rechargeAccountAmount) THEN
		SET rechargeAccountAmount = 0.0;
	END IF;
	IF ISNULL(memberShipTaxAmount) THEN
		SET memberShipTaxAmount = 0.0;
	END IF;
	IF ISNULL(totalAmount) THEN
		SET totalAmount = 0.0;
	END IF;

	SET totalAmount = totalAmount - rechargeAccountAmount;
	
	INSERT INTO manage_trade VALUES(null, extendStorageAmount, contractAmount, rechargeAccountAmount, memberShipTaxAmount, totalAmount, null);
END;
