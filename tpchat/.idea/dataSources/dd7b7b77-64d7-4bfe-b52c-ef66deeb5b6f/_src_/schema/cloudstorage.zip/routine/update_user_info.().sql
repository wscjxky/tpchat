CREATE PROCEDURE update_user_info()
  BEGIN
	DECLARE customerCount BIGINT;
	DECLARE producerCount BIGINT;
	
	SELECT COUNT(*) INTO customerCount FROM `user` JOIN domain on `user`.DomainId=domain.Id WHERE domain.IsService = 0;
	SELECT COUNT(*) INTO producerCount FROM `user` JOIN domain on `user`.DomainId=domain.Id WHERE domain.IsService = 1;
	INSERT INTO manage_user VALUES(null, customerCount, producerCount, null);
END;
