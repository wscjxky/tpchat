CREATE PROCEDURE update_storage_info()
  BEGIN
	DECLARE userStorage BIGINT;
	DECLARE usedStorage BIGINT;
	DECLARE platformStorage BIGINT;
	SELECT SUM(domain.DefaultStorageSize+domain.ExtendStorageSize), SUM(domain.UsedSize) INTO userStorage,usedStorage FROM domain; 
	SELECT platformSetting.StorageSize INTO platformStorage FROM platformSetting WHERE platformSetting.Id=1;
	INSERT INTO manage_storage VALUES(null, platformStorage, userStorage, usedStorage, null);
END;
