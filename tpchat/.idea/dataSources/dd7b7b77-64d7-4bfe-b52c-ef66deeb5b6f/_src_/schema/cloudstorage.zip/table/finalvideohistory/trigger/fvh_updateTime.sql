CREATE TRIGGER fvh_updateTime
BEFORE INSERT ON finalvideohistory
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
