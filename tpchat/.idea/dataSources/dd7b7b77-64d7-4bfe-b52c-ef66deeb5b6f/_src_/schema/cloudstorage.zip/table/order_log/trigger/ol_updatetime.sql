CREATE TRIGGER ol_updatetime
BEFORE INSERT ON order_log
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
