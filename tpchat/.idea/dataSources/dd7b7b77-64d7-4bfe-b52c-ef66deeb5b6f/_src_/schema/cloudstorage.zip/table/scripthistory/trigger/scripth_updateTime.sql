CREATE TRIGGER scripth_updateTime
BEFORE INSERT ON scripthistory
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
