CREATE TRIGGER pm_updateTime
BEFORE INSERT ON platform_msg
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
