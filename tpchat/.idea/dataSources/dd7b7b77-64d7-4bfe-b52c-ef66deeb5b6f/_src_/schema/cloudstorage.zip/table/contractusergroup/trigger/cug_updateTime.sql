CREATE TRIGGER cug_updateTime
BEFORE INSERT ON contractusergroup
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
