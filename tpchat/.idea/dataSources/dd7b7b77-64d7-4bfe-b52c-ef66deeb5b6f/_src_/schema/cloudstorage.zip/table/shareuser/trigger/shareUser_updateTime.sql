CREATE TRIGGER shareUser_updateTime
BEFORE INSERT ON shareuser
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
