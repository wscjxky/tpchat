CREATE TRIGGER cch_updateTime
BEFORE INSERT ON contractclipshistory
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
