CREATE TRIGGER share_updateTime
BEFORE INSERT ON share
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
