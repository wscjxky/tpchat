CREATE TRIGGER order_updateItme
BEFORE INSERT ON `order`
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
