CREATE TRIGGER schemeh_updateTime
BEFORE INSERT ON schemehistory
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
