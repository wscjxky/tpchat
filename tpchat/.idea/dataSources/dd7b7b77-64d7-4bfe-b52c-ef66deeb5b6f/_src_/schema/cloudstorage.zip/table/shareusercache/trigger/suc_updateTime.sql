CREATE TRIGGER suc_updateTime
BEFORE INSERT ON shareusercache
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
