CREATE TRIGGER storageShare_updateTime
BEFORE INSERT ON storage_share
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
