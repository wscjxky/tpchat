CREATE TRIGGER reqFollower
BEFORE INSERT ON requirement_follower
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
