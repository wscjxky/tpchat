CREATE TRIGGER groupUser_updateTime
BEFORE INSERT ON groupuser
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
