CREATE TRIGGER file_updateTime
BEFORE INSERT ON file
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
