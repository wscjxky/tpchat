CREATE TRIGGER role_updateTime
BEFORE INSERT ON role
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
