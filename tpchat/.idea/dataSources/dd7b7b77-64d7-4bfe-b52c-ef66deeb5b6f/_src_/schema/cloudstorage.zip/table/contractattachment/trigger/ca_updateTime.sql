CREATE TRIGGER ca_updateTime
BEFORE INSERT ON contractattachment
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
