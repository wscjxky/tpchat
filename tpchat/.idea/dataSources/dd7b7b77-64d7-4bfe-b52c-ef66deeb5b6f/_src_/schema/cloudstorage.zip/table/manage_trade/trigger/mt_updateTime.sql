CREATE TRIGGER mt_updateTime
BEFORE INSERT ON manage_trade
FOR EACH ROW
  BEGIN
	set new.UpdateTime = NOW();
end;
