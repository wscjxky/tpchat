CREATE TRIGGER cr_updateTime
BEFORE INSERT ON contractreply
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
