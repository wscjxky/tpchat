CREATE TRIGGER extendso_updateTime
BEFORE INSERT ON extendStorage_order
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
