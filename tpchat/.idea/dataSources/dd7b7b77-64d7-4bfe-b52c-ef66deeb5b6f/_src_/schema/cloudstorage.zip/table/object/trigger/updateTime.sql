CREATE TRIGGER updateTime
BEFORE INSERT ON object
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
	set new.ModifyTime = NOW();
end;
