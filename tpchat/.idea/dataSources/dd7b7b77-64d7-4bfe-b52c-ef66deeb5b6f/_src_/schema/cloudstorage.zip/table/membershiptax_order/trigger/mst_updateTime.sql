CREATE TRIGGER mst_updateTime
BEFORE INSERT ON membershiptax_order
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
