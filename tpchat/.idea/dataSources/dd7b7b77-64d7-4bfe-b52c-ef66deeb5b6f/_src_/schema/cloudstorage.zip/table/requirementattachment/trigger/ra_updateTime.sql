CREATE TRIGGER ra_updateTime
BEFORE INSERT ON requirementattachment
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
