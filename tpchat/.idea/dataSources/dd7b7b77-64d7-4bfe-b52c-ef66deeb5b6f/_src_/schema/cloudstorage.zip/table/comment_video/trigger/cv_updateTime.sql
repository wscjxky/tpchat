CREATE TRIGGER cv_updateTime
BEFORE INSERT ON comment_video
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
