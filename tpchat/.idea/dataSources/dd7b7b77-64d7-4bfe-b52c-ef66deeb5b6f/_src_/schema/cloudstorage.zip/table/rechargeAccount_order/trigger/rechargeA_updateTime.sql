CREATE TRIGGER rechargeA_updateTime
BEFORE INSERT ON rechargeAccount_order
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
