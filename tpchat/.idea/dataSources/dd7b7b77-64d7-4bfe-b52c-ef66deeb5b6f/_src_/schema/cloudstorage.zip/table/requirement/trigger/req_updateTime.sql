CREATE TRIGGER req_updateTime
BEFORE INSERT ON requirement
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
