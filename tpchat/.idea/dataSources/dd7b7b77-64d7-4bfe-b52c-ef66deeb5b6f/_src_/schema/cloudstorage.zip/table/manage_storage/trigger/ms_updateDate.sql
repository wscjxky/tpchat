CREATE TRIGGER ms_updateDate
BEFORE INSERT ON manage_storage
FOR EACH ROW
  BEGIN
	set new.UpdateTime = NOW();
end;
