CREATE TRIGGER mu_updateTime
BEFORE INSERT ON manage_user
FOR EACH ROW
  BEGIN
	set new.UpdateTime = NOW();
end;
