CREATE TRIGGER sharetu_updateTime
BEFORE INSERT ON sharetypeuser
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
