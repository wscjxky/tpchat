CREATE TRIGGER rvh_updateTime
BEFORE INSERT ON reviewvideohistory
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
