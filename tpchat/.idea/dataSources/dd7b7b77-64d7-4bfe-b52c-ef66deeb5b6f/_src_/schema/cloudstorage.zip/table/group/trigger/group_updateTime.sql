CREATE TRIGGER group_updateTime
BEFORE INSERT ON `group`
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
