CREATE TRIGGER registeridentity_updateTIme
BEFORE INSERT ON registeridentity
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
