CREATE TRIGGER contractEvn_updateTime
BEFORE INSERT ON contracteventlog
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();	
end;
