CREATE TRIGGER rr_updateTime
BEFORE INSERT ON requirementreply
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
