CREATE TRIGGER contractSeg_updateTime
BEFORE INSERT ON contractsegment
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
