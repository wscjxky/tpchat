CREATE TRIGGER domain_updateTime
BEFORE INSERT ON domain
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
