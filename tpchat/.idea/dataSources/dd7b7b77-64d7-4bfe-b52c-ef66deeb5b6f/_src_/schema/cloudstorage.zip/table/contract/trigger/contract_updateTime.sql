CREATE TRIGGER contract_updateTime
BEFORE INSERT ON contract
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
