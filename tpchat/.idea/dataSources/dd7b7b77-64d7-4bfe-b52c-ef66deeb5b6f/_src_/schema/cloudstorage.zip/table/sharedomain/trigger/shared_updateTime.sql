CREATE TRIGGER shared_updateTime
BEFORE INSERT ON sharedomain
FOR EACH ROW
  BEGIN
	set new.CreateTime = NOW();
end;
